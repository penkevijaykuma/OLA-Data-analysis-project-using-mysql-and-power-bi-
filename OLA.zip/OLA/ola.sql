create database ola;
use ola;

select * from ola;

-- -___________________________________________
-- 1. retrieve all successul bookings ? 
select * from ola 
where booking_status='success';
-- ____________________________________________

-- ___________________________________________
-- 2. find the average ride distance for each vehicle type ? 
select * from ola;
select vehicle_type ,avg(ride_distance) from ola 
group by vehicle_type;
-- _____________________________________________

-- _____________________________________________
-- 3. get the total number of canceled rides by customer ? 
select * from ola;
select booking_status, count(booking_status) from ola
where booking_status='canceled by customer'
 group by booking_status;
-- _____________________________________________

-- _____________________________________________
-- 4. list the top 5 customers who booked the highest no of rides ? 
select * from ola;
select customer_id,count(*) 
from ola
group by customer_id
order by count(*) desc
limit 5;  
-- ____________________________________________________

-- ____________________________________________________
-- 5. get the no of rides cancelled by driver due to personal and car releated issue ? 
select * from ola;
SELECT canceled_rides_by_driver, COUNT(*)
FROM ola
where canceled_rides_by_driver='Personal & Car related issue';
-- _________________________________________________________

-- _________________________________________________________
-- 6. find the maximum and minimum driver ratings for prime sedan bookings ? 
select   * from ola;
select max(driver_ratings),min(driver_ratings) 
from ola 
where vehicle_type='prime sedan';
-- _________________________________________________________

-- __________________________________________________________
-- 7. retrive all riders where payment was made using upi ? 
select payment_method from ola
where payment_method='upi';
-- __________________________________________________________

-- __________________________________________________________
-- 8. find the average customers rating per vehicle type ?
select * from ola; 
select vehicle_type ,round(avg(customer_rating),2)  
from ola
group by vehicle_type;
-- ___________________________________________________________

-- ___________________________________________________________
-- 9. calculate the total booking value of rides completed successfully ? 
select * from ola;
select booking_status,count(*) from ola 
where booking_status='success';
-- _____________________________________________________________

-- _____________________________________________________________
-- 10.list all incomplete rides along with the reason ? 
select incomplete_rides , incomplete_rides_reason from ola
where incomplete_rides='yes';